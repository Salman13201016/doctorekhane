import json
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from DOC.settings import DEFAULT_FROM_EMAIL
from django.views.decorators.csrf import csrf_exempt

from contact.models import ContactMessage

@csrf_exempt
def contact_view(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body)
            
            # Extract data from request
            name = data.get('name', '')
            email = data.get('email', '')
            phone = data.get('phone', '')
            message = data.get('message', '')
            
            # Save data to the database
            contact_message = ContactMessage.objects.create(
                name=name,
                email=email,
                phone=phone,
                message=message
            )

            subject = 'Inquiry from ' + name
            message = f'Name: {name}\nEmail: {email}\nPhone: {phone}\nMessage: {message}'
            from_email = DEFAULT_FROM_EMAIL
            to_email = DEFAULT_FROM_EMAIL
            send_mail(subject, message, from_email, [to_email], fail_silently=True)

            return JsonResponse({"message": "Form submitted successfully"}, status=200)
    except Exception as e:
        return JsonResponse({"message": str(e)}, status=500)
